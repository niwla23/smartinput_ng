""""rgb color constants"""
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)
TURQOIUSE = (0, 255, 0)
BLUE = (0, 0, 255)
PINK = (255, 0, 255)