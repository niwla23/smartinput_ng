num_pixels = 4
baudrate = 115200
timeout=0.1